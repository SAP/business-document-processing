This is a collection of fake **invoices, purchase orders, payment advices and other business documents** for demo purposes.
Logos were downloaded from search.creativecommons.org, all licensed under [CC BY 2.0](https://creativecommons.org/licenses/by/2.0/)
Logos were embedded in the documents in this repository unaltered.

- "Logo Engenharia ambiental" by Felipe Skroski is licensed with CC BY 2.0.
- "NAVFAC Primary Logo" by NAVFAC is licensed with CC BY 2.0.
- "Logo candidate for 2nd Chinese Blogger Conference" by IsaacMao is licensed with CC BY 2.0.
- "Logo of Twitter" by topgold is licensed with CC BY 2.0.
- "RC Logo" by Felipe Skroski is licensed with CC BY 2.0.
- "Logo of Flickr" by topgold is licensed with CC BY 2.0.
- "umbro logo" by sefcmpa is licensed with CC BY 2.0.
- "Logo Norsk Folkehjelp Sanitet" by folkehjelp is licensed with CC BY 2.0.
- "Logo Guru Shop" by Carlo Armanni is licensed with CC BY 2.0.